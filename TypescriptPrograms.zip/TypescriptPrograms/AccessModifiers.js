var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var greetings = /** @class */ (function () {
    function greetings(name, gender, age) {
        this.name = name;
        this.gender = gender;
        this.age = age;
    }
    greetings.prototype.diplay = function () {
        console.log("Name:- " + this.name);
        console.log("gender:- " + this.gender);
        console.log("age:- " + this.age);
    };
    return greetings;
}());
var Student = /** @class */ (function (_super) {
    __extends(Student, _super);
    function Student(name, gender, age) {
        return _super.call(this, name, gender, age) || this;
    }
    Student.prototype.displayStudentDetails = function () {
        _super.prototype.diplay.call(this);
    };
    return Student;
}(greetings));
var s = new Student("Nishith", "Male", 23);
s.displayStudentDetails();
