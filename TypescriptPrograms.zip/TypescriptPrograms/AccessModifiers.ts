class greetings{
    public name:string;
    private gender:string;
    protected age:number;

    constructor(name:string, gender:string, age:number){
        this.name= name;
        this.gender= gender;
        this.age= age;
    }

    diplay():void{
        console.log("Name:- "+ this.name);
        console.log("gender:- "+ this.gender);
        console.log("age:- "+ this.age);  
    }    
}

class Student extends greetings{
        
    constructor(name:string, gender:string, age:number){
                super(name,gender,age);
                }

        displayStudentDetails(){
            super.diplay();
        }
}
let s= new Student("Nishith","Male",23);
s.displayStudentDetails();


