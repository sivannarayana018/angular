//(function(){
var days;
(function (days) {
    days[days["monday"] = 1] = "monday";
    days[days["tuesday"] = 2] = "tuesday";
    days[days["wednesday"] = 3] = "wednesday";
    days[days["thursday"] = 4] = "thursday";
    days[days["friday"] = 5] = "friday";
    days[days["saturday"] = 6] = "saturday";
    days[days["sunday"] = 7] = "sunday";
})(days || (days = {}));
var getDay = function () { return 1; };
var today = getDay();
console.log(days[today]);
/*
Date.prototype.toLocaleDateString = function(){
    return days[this.getDay()];
};

})()
var date=new Date();
var day = date.getDay();
console.log(day);*/ 
