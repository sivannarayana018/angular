//(function(){

    enum days{
        monday = 1,
        tuesday = 2,
        wednesday = 3 ,
        thursday = 4,
        friday = 5,
        saturday = 6,
        sunday = 7
    }
    const getDay = () => 1;  
    const today = getDay();
    console.log(days[today]);
    /*
    Date.prototype.toLocaleDateString = function(){
        return days[this.getDay()];
    };
    
    })()
    var date=new Date();
    var day = date.getDay();
    console.log(day);*/