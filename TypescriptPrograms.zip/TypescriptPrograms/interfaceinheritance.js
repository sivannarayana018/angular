;
function dateTimeMethod(dateAndTime) { }
var t = {};
t.dateAndTime = Date();
console.log(t);
