interface todaysDateAndTime{
    dateAndTime:string;
}

interface dateAndTimeMethod extends todaysDateAndTime{
    
    dateTimeMethod(dateAndTime:string):void
};

function dateTimeMethod(dateAndTime:string){}

let t = <dateAndTimeMethod>{}
    t.dateAndTime = Date()
    console.log(t);




